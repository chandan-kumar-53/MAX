/**
@THIS FILE , 
        EXPERIMENTED ON 
	        - RAND_UP (double effect)
			- RAND_DOWN (double effect)
			- MAKE_BUFFER (double effect)
			- WAVE (double effect)*
		
	    CHANDAN KUMAR MONDAL (C) - 18 MAY, 2020
    *SAME EFFECT, WORKS BOTH IN AND OUT EFFECT
*/

#include <CK_MAX.h>
#include "DEBUG.h"

#define DEBUG 1
void CK_MAX::GrowMe(String message, Growing_Type G_T,Animation_Mode A_M, uint16_t duration, uint16_t wait){
	
    TRANSFER_THIS(message);
	/// OK... HERE IS THE END OF COLLECTING DATA SECTION, NOW LET'S ENTER THE ANIMATION SECTION
	
	/// TAKE A ARRAY EXACT SAME LENGTH OF THE MESSAGE
	byte buffer[LENGTH_OF_MESSAGE];
	int bitnumber = 0;
	/// CLEAN UP THIS BUFFER
if(A_M==ENTRY){
			for(uint8_t buf_id = 0; buf_id<LENGTH_OF_MESSAGE ; buf_id++){
				buffer[buf_id] = 0b00000000;
			}	
			if(G_T == UP){

				for( bitnumber = 0;bitnumber<8; bitnumber++)
				{
					for(uint8_t digitnumber = 0; digitnumber<LENGTH_OF_MESSAGE; digitnumber++){
						bitWrite(buffer[digitnumber] , bitnumber, bitRead(MY_MESSAGE_BUFFER[digitnumber],bitnumber));
					}
					
					/// DIPLAY THE SLOT
					uint8_t cursor = 0;
					uint8_t LoopNumber = 0;
					uint8_t RegNumber = 0;
		#if Correct_Align
			for(int i = digit_pos; i<digit_pos+LENGTH_OF_MESSAGE; i++){
				LoopNumber = givethecursor(i);
		#else 
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		#endif
					RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
					ForceExecute(buffer[cursor],LoopNumber,RegNumber);
					cursor++;
					}
					delay(duration);
				}
			}
			else if (G_T == DOWN)
			{
				for( bitnumber = 7;bitnumber>=0; bitnumber--)
				{
					for(uint8_t digitnumber = 0; digitnumber<LENGTH_OF_MESSAGE; digitnumber++){
						bitWrite(buffer[digitnumber] , bitnumber, bitRead(MY_MESSAGE_BUFFER[digitnumber],bitnumber));
					}
					
					/// DIPLAY THE SLOT
					uint8_t cursor = 0;
					uint8_t LoopNumber = 0;
					uint8_t RegNumber = 0;
		#if Correct_Align
			for(int i = digit_pos; i<digit_pos+LENGTH_OF_MESSAGE; i++){
				LoopNumber = givethecursor(i);
		#else 
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		#endif
					RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
					ForceExecute(buffer[cursor],LoopNumber,RegNumber);
					cursor++;
					}
					delay(duration);
				}
			}
			else if(G_T==BUFFERING){
				// FIRST CREATE A SPIN EFFECT,
				byte spin_buffer[LENGTH_OF_MESSAGE];
				// STORE THE INITIAL VALUE,
					for(uint8_t counter = 0; counter<SPIN_COUNTER; counter++) {
							for(uint8_t id = 0;id<LENGTH_OF_MESSAGE; id++){
								spin_buffer[id] = 0b11000000;
							}
							for(int index = 0;index<5;index++){
								for(int dig = 0;dig < LENGTH_OF_MESSAGE; dig++){
									spin_buffer[dig]=spin_buffer[dig]>>1;
								}
								//SHOW THE SPIN EFFECT, 
								uint8_t cursor = 0;
								uint8_t LoopNumber = 0;
								uint8_t RegNumber = 0;
					#if Correct_Align
						for(int i = digit_pos; i<digit_pos+LENGTH_OF_MESSAGE; i++){
							LoopNumber = givethecursor(i);
					#else 
						for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
							LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
					#endif
								RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
								ForceExecute(spin_buffer[cursor],LoopNumber,RegNumber);
								cursor++;
								}
								delay(duration);
							}
						}
				///RefreshMe();
				uint8_t cursor=0;
				uint8_t LoopNumber = 0;
				uint8_t RegNumber = 0;
					#if Correct_Align
						for(int i = digit_pos; i<digit_pos+LENGTH_OF_MESSAGE; i++){
							LoopNumber = givethecursor(i);
					#else 
						for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
							LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
					#endif
								RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
								ForceExecute(MY_MESSAGE_BUFFER[cursor],LoopNumber,RegNumber);
								cursor++;
								}
								delay(duration);
							}
			delay(wait);
			if(Internal_Refresh){
				RefreshMe();
			}
	}else{
		for(uint8_t index = 0; index < LENGTH_OF_MESSAGE ; index++){
			buffer[index] = MY_MESSAGE_BUFFER[index];
		}
		if(G_T==UP){
			for( bitnumber = 0;bitnumber<8; bitnumber++)
				{
					for(uint8_t digitnumber = 0; digitnumber<LENGTH_OF_MESSAGE; digitnumber++){
						bitClear(buffer[digitnumber] , bitnumber);
					}
					
					/// DIPLAY THE SLOT
					uint8_t cursor = 0;
					uint8_t LoopNumber = 0;
					uint8_t RegNumber = 0;
		#if Correct_Align
			for(int i = digit_pos; i<digit_pos+LENGTH_OF_MESSAGE; i++){
				LoopNumber = givethecursor(i);
		#else 
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		#endif
					RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
					ForceExecute(buffer[cursor],LoopNumber,RegNumber);
					cursor++;
					}
					delay(duration);
				}
		}

		else if(G_T == DOWN){
			for( bitnumber = 7;bitnumber>=0; bitnumber--)
				{
					for(uint8_t digitnumber = 0; digitnumber<LENGTH_OF_MESSAGE; digitnumber++){
						bitClear(buffer[digitnumber] , bitnumber);
					}
					
					/// DIPLAY THE SLOT
					uint8_t cursor = 0;
					uint8_t LoopNumber = 0;
					uint8_t RegNumber = 0;
		#if Correct_Align
			for(int i = digit_pos; i<digit_pos+LENGTH_OF_MESSAGE; i++){
				LoopNumber = givethecursor(i);
		#else 
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		#endif
					RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
					ForceExecute(buffer[cursor],LoopNumber,RegNumber);
					cursor++;
					}
					delay(duration);
				}
		}

		if(G_T==BUFFERING){
			byte spin_buffer[LENGTH_OF_MESSAGE];
				// STORE THE INITIAL VALUE,
					for(uint8_t counter = 0; counter<SPIN_COUNTER; counter++) {
							for(uint8_t id = 0;id<LENGTH_OF_MESSAGE; id++){
								spin_buffer[id] = 0b11000000;
							}
							for(int index = 0;index<5;index++){
								for(int dig = 0;dig < LENGTH_OF_MESSAGE; dig++){
									spin_buffer[dig]=spin_buffer[dig]>>1;
								}
								//SHOW THE SPIN EFFECT, 
								uint8_t cursor = 0;
								uint8_t LoopNumber = 0;
								uint8_t RegNumber = 0;
					#if Correct_Align
						for(int i = digit_pos; i<digit_pos+LENGTH_OF_MESSAGE; i++){
							LoopNumber = givethecursor(i);
					#else 
						for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
							LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
					#endif
								RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
								ForceExecute(spin_buffer[cursor],LoopNumber,RegNumber);
								cursor++;
								}
								delay(duration);
							}
						}
				///RefreshMe();
				uint8_t cursor=0;
				uint8_t LoopNumber = 0;
				uint8_t RegNumber = 0;
					#if Correct_Align
						for(int i = digit_pos; i<digit_pos+LENGTH_OF_MESSAGE; i++){
							LoopNumber = givethecursor(i);
					#else 
						for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
							LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
					#endif
								RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
								ForceExecute(0b00000000,LoopNumber,RegNumber);
								cursor++;
								}
								delay(duration);
							}
		}
	}
	

/// * UP * DOWN * BUFFERING

void CK_MAX:: WaveMe(String message, uint16_t duration, uint16_t wait){
	TRANSFER_THIS(message);
	
	byte WAVE_BUFFER[LENGTH_OF_MESSAGE];
	
	/// FIRST PRINT THE MESSAGE BUFFER ....
	    int LoopNumber = 0;
	    byte RegNumber = 0;
	    // DISPLAY SECTION.....
	    int Cursor_pos = 0;
	    for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
		   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
		   ForceExecute(MY_MESSAGE_BUFFER[Cursor_pos], LoopNumber, RegNumber);
		   Cursor_pos++;
	    }
	delay(duration);
	
	/// TAKE THE MESSAGE BUFFER
	for(int index = 0; index <LENGTH_OF_MESSAGE; index++){
		WAVE_BUFFER[index] = MY_MESSAGE_BUFFER[index];
	}
	
	for(int index = 0; index <LENGTH_OF_MESSAGE ;index++){
		/// ROTATE SINGLE CHARACTER
		bitWrite(WAVE_BUFFER[index], 0, bitRead(MY_MESSAGE_BUFFER[index], 0));//NEW G - OLD G
		bitWrite(WAVE_BUFFER[index], 1, bitRead(MY_MESSAGE_BUFFER[index], 4));//NEW F - OLD D
		bitWrite(WAVE_BUFFER[index], 2, bitRead(MY_MESSAGE_BUFFER[index], 5));//NEW E - OLD B
		bitWrite(WAVE_BUFFER[index], 3, bitRead(MY_MESSAGE_BUFFER[index], 6));//NEW D - OLD A
		bitWrite(WAVE_BUFFER[index], 4, bitRead(MY_MESSAGE_BUFFER[index], 1));//NEW C - OLD F
		bitWrite(WAVE_BUFFER[index], 5, bitRead(MY_MESSAGE_BUFFER[index], 2));//NEW D - OLD E
		bitWrite(WAVE_BUFFER[index], 6, bitRead(MY_MESSAGE_BUFFER[index], 3));//NEW A - OLD D
		bitClear(WAVE_BUFFER[index], 7);                                   // CLAER THE DECIMAL POINT
		
		/// PRINTIT
		int LoopNumber = 0;
	    byte RegNumber = 0;
	    // DISPLAY SECTION.....
	    int Cursor_pos = 0;
	    for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
		   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
		   ForceExecute(WAVE_BUFFER[Cursor_pos], LoopNumber, RegNumber);
		   Cursor_pos++;
	    }
		/// DELAY
		delay(duration);	
	}
	
	delay(duration);
	
	/// AGAIN ROTATE....
	/// PRINTIT
	     Cursor_pos = 1;
	    for(int i = digit_pos-LENGTH_OF_MESSAGE+1; i<=digit_pos; i++){
		   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
		   ForceExecute(MY_MESSAGE_BUFFER[LENGTH_OF_MESSAGE-Cursor_pos], LoopNumber, RegNumber);
		   Cursor_pos++;
		   delay(duration);
	    }
		delay(wait);
	if(Internal_Refresh){	
		RefreshMe();
	}
}
//  * WAVE