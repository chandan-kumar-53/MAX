#include<CK_MAX.h>

/**
    \name FlowMe
	\brief It is mainly the scrolling effect. Every character will be scrolled in single frame. It has two category
	             - Scroll Up
				      * In Effect
					  * Out Effect
				 - Scroll down
				      * In Effect
					  * Out Effect
					  
	\def Scroll Up (In 
	
	       a                                    a
		+-----+                              +-----+
	  f |     | b                          f |     |  b 
		|  g  |                    a         |  g  |
		+-----+                 +-----+      +-----+
	  e |     | c             f |     |  b e |     |  c 
		|     |        a        |  g  |      |     |
		+-----+     +-----+     +-----+      +-----+
		   d        |     |     |     |         d
	   (DISPLAY)    |     |     |     |     (FRAME 3)
	                +-----+     +-----+
					|     |    (FRAME 2)
					|     |
					+-----+
				   (FRAME 1)
				   
		0 b 0 0 0 0 0 0 0 0
		   dp a b c d e f g
	        7 6 5 4 3 2 1 0 - index
	
	
		\brief FRAME 1
		     display (d) -> digit (a)   3->6
		\brief FRAME 2
		     display (g) -> digit (a)   0->6
			 display (c) -> digit (b)   4->5
			 disable (d) -> digit (g)   3->0
			 display (e) -> digit (f)   2->1
		\brief FRAME 3
		     display     -> digit
			 
			 
	\def Scroll Up (Out Effect)
	
                                                +-----+
                                                |     |
                                                |     |
                                   +-----+      +-----+
                                   |     |      |     |
	       a            a          |  g  |      |     |
		+-----+      +-----+       +-----+      +-----+
	  f |     | b  f |     |  b  e |     | c       d 
		|  g  |      |  g  |       |     |     (FRAME 3)
		+-----+      +-----+       +-----+
	  e |     | c  e |     |  c       d
		|     |      |     |      (FRAME 2)
		+-----+      +-----+
		   d             d
	   (DISPLAY)     (FRAME 1)
        
        \brief FRAME 1
            display     -> digit
		\brief FRAME 2
            display (a) -> digit (g)
            display (b) -> digit (c)
            display (g) -> digit (d)
            display (f) -> digit (e)
		\brief FRAME 3
            display (a) -> digit (d)

			
    \def Scroll Down (In Effect)
         -> same as Scroll up (Out Effect)		

    \def Scroll Down (Out Effect)		 
	     -> same as Scroll Up (In Effect)

		
*/
void CK_MAX::FlowMe(String message, Flow_Type F_T, Animation_Mode A_M,  uint16_t duration, uint16_t wait){
	TRANSFER_THIS(message);
	
	/// CREATE A SAME LENGTH BOX
	byte box[LENGTH_OF_MESSAGE];

	if(A_M==ENTRY){
		for(uint8_t index = 0; index < LENGTH_OF_MESSAGE ; index++){
			box[index] = 0b00000000;
		}
		
		// IT SHOW THREE STEPS
		for(uint8_t i=0;i<3;i++){
			for(uint8_t index = 0; index < LENGTH_OF_MESSAGE ; index++){
				box[index] = 0b00000000;
				}
			for(uint8_t index = 0;index<LENGTH_OF_MESSAGE;index++){
				if(F_T==GO_UP){
					switch(i){
						case 0:
						bitWrite(box[index], 3, bitRead(MY_MESSAGE_BUFFER[index], 6));
						break;
						
						case 1:
						bitWrite(box[index], 0, bitRead(MY_MESSAGE_BUFFER[index], 6));
						bitWrite(box[index], 2, bitRead(MY_MESSAGE_BUFFER[index], 1));
						bitWrite(box[index], 4, bitRead(MY_MESSAGE_BUFFER[index], 5));
						bitWrite(box[index], 3, bitRead(MY_MESSAGE_BUFFER[index], 0));
						break;
						
						case 2:
						box[index] = MY_MESSAGE_BUFFER[index];
						break;
					}
				}else{
					switch(i){
						case 0:
						bitWrite(box[index], 6, bitRead(MY_MESSAGE_BUFFER[index], 3));
						break;
						
						case 1:
						bitWrite(box[index], 0, bitRead(MY_MESSAGE_BUFFER[index], 3));
						bitWrite(box[index], 6, bitRead(MY_MESSAGE_BUFFER[index], 0));
						bitWrite(box[index], 1, bitRead(MY_MESSAGE_BUFFER[index], 2));
						bitWrite(box[index], 5, bitRead(MY_MESSAGE_BUFFER[index], 4));
						break;
						
						case 2:
						box[index] = MY_MESSAGE_BUFFER[index];
						break;
					}
					
				}
			}
			
			int LoopNumber = 0;
			byte RegNumber = 0;
			// DISPLAY SECTION.....
			int Cursor_pos = 0;
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
			LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
			RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
			ForceExecute(box[Cursor_pos], LoopNumber, RegNumber);
			Cursor_pos++;
			}
			delay(duration);
		}
		delay(wait);
		if(Internal_Refresh){
			RefreshMe();
		}
//EXIT................
   }else{
	   for(uint8_t index = 0; index < LENGTH_OF_MESSAGE ; index++){
			box[index] = 0b00000000;
		}
		
		// IT SHOW THREE STEPS
		for(uint8_t i=0;i<4;i++){
			for(uint8_t index = 0; index < LENGTH_OF_MESSAGE ; index++){
				box[index] = 0b00000000;
				}
			for(uint8_t index = 0;index<LENGTH_OF_MESSAGE;index++){
				if(F_T==GO_UP){
					switch(i){
						case 0:
						box[index] = MY_MESSAGE_BUFFER[index];
						break;
						
						case 1:
						bitWrite(box[index], 0, bitRead(MY_MESSAGE_BUFFER[index], 3));
						bitWrite(box[index], 6, bitRead(MY_MESSAGE_BUFFER[index], 0));
						bitWrite(box[index], 1, bitRead(MY_MESSAGE_BUFFER[index], 2));
						bitWrite(box[index], 5, bitRead(MY_MESSAGE_BUFFER[index], 4));
						break;
						
						case 2:
						bitWrite(box[index], 6, bitRead(MY_MESSAGE_BUFFER[index], 3));
						break;
						
						case 3:
						box[index] = 0b00000000;
						break;
					}
				}else{
					switch(i){
						case 0:
						box[index] = MY_MESSAGE_BUFFER[index];
						break;
						
						case 1:
						bitWrite(box[index], 0, bitRead(MY_MESSAGE_BUFFER[index], 6));
						bitWrite(box[index], 2, bitRead(MY_MESSAGE_BUFFER[index], 1));
						bitWrite(box[index], 4, bitRead(MY_MESSAGE_BUFFER[index], 5));
						bitWrite(box[index], 3, bitRead(MY_MESSAGE_BUFFER[index], 0));
						break;
						
						case 2:
						bitWrite(box[index], 3, bitRead(MY_MESSAGE_BUFFER[index], 6));
						break;
						
						case 3:
						box[index] = 0b00000000;
						break;
					}
					
				}
			}
			
			int LoopNumber = 0;
			byte RegNumber = 0;
			// DISPLAY SECTION.....
			int Cursor_pos = 0;
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
			LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
			RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
			ForceExecute(box[Cursor_pos], LoopNumber, RegNumber);
			Cursor_pos++;
			}
			delay(duration);
		}
   }
}