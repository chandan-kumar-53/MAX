/**
        EXPERIMENT ON SCROLLING EFFECT OF CK_MAX LIBRARY....
			-SCROLL LEFT TO RIGHT
			-SCROLL RIGHT TO LEFT
	    > DOESN'T WORK WITH LEFT_TO_RIGHT MODULE
		
		CHANDAN KUMAR MONDAL (C) - 17 MAY, 2020
*/

#include <CK_MAX.h>
#include "DEBUG.h"

#define DEBUG 0

void CK_MAX::ScrollMe(String message,Scroll_Type S_t, uint16_t duration){
    TRANSFER_THIS(message);
 
/// TAKE A DISPLAY BUFFER, AND SIZE OF THIS ARRAY WILL BE THE DISPLAY SIZE AND THE DOUBLE SIZE OF THE MESSAGE
	uint16_t size_of_buffer = (Number_of_Device * DIGIT_NUMBER) + (2*LENGTH_OF_MESSAGE);
	byte display_buffer[size_of_buffer];
/// CLEAR THIS BUFFER
	for(int x = 0;x<size_of_buffer;x++){
		display_buffer[x] = 0;
	}
/// TAKE THE MESSAGE BUFFER INTO THE DISPLAY BUFFER
	if(S_t == LEFT_TO_RIGHT){
		for(int x=0;x<LENGTH_OF_MESSAGE;x++){
			display_buffer[x] = MY_MESSAGE_BUFFER[x];
		}
	}else{
		for(int x=1;x<=LENGTH_OF_MESSAGE;x++){
			display_buffer[size_of_buffer-x] = MY_MESSAGE_BUFFER[LENGTH_OF_MESSAGE-x];
		}
	}

   int Buffer_position = 0;
   while(Buffer_position<(size_of_buffer-LENGTH_OF_MESSAGE)){
	   if(S_t==LEFT_TO_RIGHT){
		   for(int x = Buffer_position+LENGTH_OF_MESSAGE; x>Buffer_position; x--){
		      display_buffer[x] = display_buffer[x-1];
	     }
	   }else{
		   for(int x = size_of_buffer-(LENGTH_OF_MESSAGE+Buffer_position)-1;x<=(size_of_buffer-Buffer_position)-1;x++){
			   display_buffer[x] = display_buffer[x+1];
		   }
	   }  
	   if(S_t==LEFT_TO_RIGHT){display_buffer[Buffer_position] = 0; }
	   else{ display_buffer[size_of_buffer-Buffer_position-1] = 0; }
	   
	   int LoopNumber = 0;
	   byte RegNumber = 0;
	   // DISPLAY SECTION.....
	   int Cursor_pos = 0;
	   for(int i = Number_of_Device*DIGIT_NUMBER; i>0; i--){
		   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
		   ForceExecute(display_buffer[LENGTH_OF_MESSAGE+Cursor_pos], LoopNumber, RegNumber);
		   Cursor_pos++;
	   }

	   // WAIT THE GIVEN TIME
	   delay(duration);

	   // INCREMENT THE BUFFER POSITION
	   Buffer_position++;
   }
}

/// *RIGHT_TO_LEFT *LEFT_TO_RIGHT