    /**
@THIS FILE, 
    EXPERIMENTED ON,
	        - SCAN_TOP (double effect)
			- SCAN_BOTTOM (double effect)
			- MAKE (double effect)
			- BREAK (double effect)
		COPYRIGHT : CHANDAN KUMAR MONDAL (25 MAY, 2020)
*/

#include <CK_MAX.h>

void CK_MAX::ScanMe(String message, Scan_Type S_T, Animation_Mode A_M,uint16_t duration, uint16_t wait){
	TRANSFER_THIS(message);
	
	byte Frame[LENGTH_OF_MESSAGE];

	//************************ENTRY ANIMATION*******************************************
if(A_M==ENTRY){
	for(uint8_t index = 0;index < LENGTH_OF_MESSAGE ;index++){
		Frame[index] = 0b00000000;
	}
	for(uint8_t seq = 0; seq <8 ;seq++){
		for(uint8_t digit = 0; digit<LENGTH_OF_MESSAGE; digit++){
			if(S_T==TOP){
			  switch(seq){
				  case 0:
				  bitWrite(Frame[digit], 6, bitRead(MY_MESSAGE_BUFFER[digit], 6));
				  break;
				  
				  case 1:
				  bitWrite(Frame[digit], 1, bitRead(MY_MESSAGE_BUFFER[digit], 1));
				  break;
				  
				  case 2:
				  bitWrite(Frame[digit], 5, bitRead(MY_MESSAGE_BUFFER[digit], 5));
				  break;
				  
				  case 3:
				  bitWrite(Frame[digit], 0, bitRead(MY_MESSAGE_BUFFER[digit], 0));
				  break;
				  
				  case 4:
				  bitWrite(Frame[digit], 2, bitRead(MY_MESSAGE_BUFFER[digit], 2));
				  break;
				  
				  case 5:
				  bitWrite(Frame[digit], 4, bitRead(MY_MESSAGE_BUFFER[digit], 4));
				  break;
				  
				  case 6:
				  bitWrite(Frame[digit], 3, bitRead(MY_MESSAGE_BUFFER[digit], 3));
				  break;
				  
				  case 7:
				  bitWrite(Frame[digit], 7, bitRead(MY_MESSAGE_BUFFER[digit], 7));
				  break;
				   
			    }
			}else{
				 switch(seq){
				  case 0:
				  bitWrite(Frame[digit], 7, bitRead(MY_MESSAGE_BUFFER[digit], 7));
				  break;
				  
				  case 1:
				  bitWrite(Frame[digit], 3, bitRead(MY_MESSAGE_BUFFER[digit], 3));
				  break;
				  
				  case 2:
				  bitWrite(Frame[digit], 4, bitRead(MY_MESSAGE_BUFFER[digit], 4));
				  break;
				  
				  case 3:
				  bitWrite(Frame[digit], 2, bitRead(MY_MESSAGE_BUFFER[digit], 2));
				  break;
				  
				  case 4:
				  bitWrite(Frame[digit], 0, bitRead(MY_MESSAGE_BUFFER[digit], 0));
				  break;
				  
				  case 5:
				  bitWrite(Frame[digit], 5, bitRead(MY_MESSAGE_BUFFER[digit], 5));
				  break;
				  
				  case 6:
				  bitWrite(Frame[digit], 1, bitRead(MY_MESSAGE_BUFFER[digit], 1));
				  break;
				  
				  case 7:
				  bitWrite(Frame[digit], 6, bitRead(MY_MESSAGE_BUFFER[digit], 6));
				  break;
			   
		        } 
			}
		  int LoopNumber = 0;
		  byte RegNumber = 0;
		  // DISPLAY SECTION.....
		  int Cursor_pos = 0;
		  for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
		   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
		   ForceExecute(Frame[Cursor_pos], LoopNumber, RegNumber);
		   Cursor_pos++;
		}
		  delay(duration);
		}
	}
	delay(wait);
	if(Internal_Refresh){
		RefreshMe();
	}
}
///***********EXIT************
else{
	// SAVE THE FRAME
	for(uint8_t index = 0; index <LENGTH_OF_MESSAGE ;index++){
		Frame[index] = MY_MESSAGE_BUFFER[index];
	}
//PRINT THE TEXT FIRST,
          int LoopNumber = 0;
		  byte RegNumber = 0;
		  // DISPLAY SECTION.....
		  int Cursor_pos = 0;
		  for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
		   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
		   ForceExecute(Frame[Cursor_pos], LoopNumber, RegNumber);
		   Cursor_pos++;
		  }

		for(uint8_t seq = 0; seq <8 ;seq++){
		for(uint8_t digit = 0; digit<LENGTH_OF_MESSAGE; digit++){
			if(S_T==TOP){
			  switch(seq){
				  case 0:
				  bitClear(Frame[digit], 6);
				  break;
				  
				  case 1:
				  bitClear(Frame[digit], 1);
				  break;
				  
				  case 2:
				  bitClear(Frame[digit], 5);
				  break;
				  
				  case 3:
				  bitClear(Frame[digit], 0);
				  break;
				  
				  case 4:
				  bitClear(Frame[digit], 2);
				  break;
				  
				  case 5:
				  bitClear(Frame[digit], 4);
				  break;
				  
				  case 6:
				  bitClear(Frame[digit], 3);
				  break;
				  
				  case 7:
				  bitClear(Frame[digit], 7);
				  break;
				   
			    }
			}else{
				 switch(seq){
				  case 0:
				  bitClear(Frame[digit], 7);
				  break;
				  
				  case 1:
				  bitClear(Frame[digit], 3);
				  break;
				  
				  case 2:
				  bitClear(Frame[digit], 4);
				  break;
				  
				  case 3:
				  bitClear(Frame[digit], 2);
				  break;
				  
				  case 4:
				  bitClear(Frame[digit], 0);
				  break;
				  
				  case 5:
				  bitClear(Frame[digit], 5);
				  break;
				  
				  case 6:
				  bitClear(Frame[digit], 1);
				  break;
				  
				  case 7:
				  bitClear(Frame[digit], 6);
				  break;
			   
		        } 
			}
		  int LoopNumber = 0;
		  byte RegNumber = 0;
		  // DISPLAY SECTION.....
		  int Cursor_pos = 0;
		  for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
		   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
		   ForceExecute(Frame[Cursor_pos], LoopNumber, RegNumber);
		   Cursor_pos++;
		}
		  delay(duration);
		}
	  }		
    }
  }

/// SCAN_TOP * SCAN_BOTTOM *

