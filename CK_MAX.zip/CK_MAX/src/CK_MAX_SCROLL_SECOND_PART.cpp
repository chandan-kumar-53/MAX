#include <CK_MAX.h>

void CK_MAX::ScrollMeNew(String message, Scroll_New_Type S_T, Animation_Mode A_M, uint16_t duration, uint16_t wait){
	TRANSFER_THIS(message);
	
	byte BUFFER[LENGTH_OF_MESSAGE];
	for(uint8_t index=0;index<LENGTH_OF_MESSAGE;index++){
		BUFFER[index] =(byte)0;
	}
	
	if(A_M==ENTRY){
		for(uint8_t digit_index = 0; digit_index<LENGTH_OF_MESSAGE;digit_index++){
			for(uint8_t step = 0; step < 3;step ++){
				BUFFER[digit_index] = 0b00000000;
				if(S_T==S_U_S){
					switch(step){
						case 0:
						bitWrite(BUFFER[digit_index], 3, bitRead(MY_MESSAGE_BUFFER[digit_index], 6));
						break;
						
						case 1:
						bitWrite(BUFFER[digit_index], 0, bitRead(MY_MESSAGE_BUFFER[digit_index], 6));
						bitWrite(BUFFER[digit_index], 2, bitRead(MY_MESSAGE_BUFFER[digit_index], 1));
						bitWrite(BUFFER[digit_index], 4, bitRead(MY_MESSAGE_BUFFER[digit_index], 5));
						bitWrite(BUFFER[digit_index], 3, bitRead(MY_MESSAGE_BUFFER[digit_index], 0));
						break;
						
						case 2:
						BUFFER[digit_index] = MY_MESSAGE_BUFFER[digit_index];
						break;
					}
				}else{
					switch(step){
						case 0:
						bitWrite(BUFFER[digit_index], 6, bitRead(MY_MESSAGE_BUFFER[digit_index], 3));
						break;
						
						case 1:
						bitWrite(BUFFER[digit_index], 0, bitRead(MY_MESSAGE_BUFFER[digit_index], 3));
						bitWrite(BUFFER[digit_index], 6, bitRead(MY_MESSAGE_BUFFER[digit_index], 0));
						bitWrite(BUFFER[digit_index], 1, bitRead(MY_MESSAGE_BUFFER[digit_index], 2));
						bitWrite(BUFFER[digit_index], 5, bitRead(MY_MESSAGE_BUFFER[digit_index], 4));
						break;
						
						case 2:
						BUFFER[digit_index] = MY_MESSAGE_BUFFER[digit_index];
						break;
					}
					
				}
				int LoopNumber = 0;
				byte RegNumber = 0;
				// DISPLAY SECTION.....
				int Cursor_pos = 0;
				for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(BUFFER[Cursor_pos], LoopNumber, RegNumber);
				Cursor_pos++;
				}
				delay(duration);
			}
		}
		delay(wait);
		if(Internal_Refresh){
			RefreshMe();
		}
	}else{
		for(uint8_t index=0;index<LENGTH_OF_MESSAGE;index++){
		BUFFER[index] =MY_MESSAGE_BUFFER[index];
	}
		       int LoopNumber = 0;
				byte RegNumber = 0;
				// DISPLAY SECTION.....
				int Cursor_pos = 0;
				for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(BUFFER[Cursor_pos], LoopNumber, RegNumber);
				Cursor_pos++;
				}
		for(uint8_t digit_index = 0; digit_index<LENGTH_OF_MESSAGE;digit_index++){
			for(uint8_t step = 0; step < 4;step ++){
				BUFFER[digit_index] = 0b00000000;
				if(S_T==S_U_S){
					switch(step){
						case 0:
						BUFFER[digit_index] = MY_MESSAGE_BUFFER[digit_index];
						break;
						
						case 1:
						bitWrite(BUFFER[digit_index], 0, bitRead(MY_MESSAGE_BUFFER[digit_index], 3));
						bitWrite(BUFFER[digit_index], 6, bitRead(MY_MESSAGE_BUFFER[digit_index], 0));
						bitWrite(BUFFER[digit_index], 1, bitRead(MY_MESSAGE_BUFFER[digit_index], 2));
						bitWrite(BUFFER[digit_index], 5, bitRead(MY_MESSAGE_BUFFER[digit_index], 4));
						break;
						
						case 2:
						bitWrite(BUFFER[digit_index], 6, bitRead(MY_MESSAGE_BUFFER[digit_index], 3));
						break;
						
						case 3:
						BUFFER[digit_index] = 0b00000000;
						break;
					}
				}else{
					switch(step){
						case 0:
						BUFFER[digit_index] = MY_MESSAGE_BUFFER[digit_index];
						break;
						
						case 1:
						bitWrite(BUFFER[digit_index], 0, bitRead(MY_MESSAGE_BUFFER[digit_index], 6));
						bitWrite(BUFFER[digit_index], 2, bitRead(MY_MESSAGE_BUFFER[digit_index], 1));
						bitWrite(BUFFER[digit_index], 4, bitRead(MY_MESSAGE_BUFFER[digit_index], 5));
						bitWrite(BUFFER[digit_index], 3, bitRead(MY_MESSAGE_BUFFER[digit_index], 0));
						break;
						
						case 2:
						bitWrite(BUFFER[digit_index], 3, bitRead(MY_MESSAGE_BUFFER[digit_index], 6));
						break;
						
						case 3:
						BUFFER[digit_index] = 0b00000000;
						break;
					}
					
				}
				int LoopNumber = 0;
				byte RegNumber = 0;
				// DISPLAY SECTION.....
				int Cursor_pos = 0;
				for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(BUFFER[Cursor_pos], LoopNumber, RegNumber);
				Cursor_pos++;
				}
				delay(duration);
			}
		}
	}
}

