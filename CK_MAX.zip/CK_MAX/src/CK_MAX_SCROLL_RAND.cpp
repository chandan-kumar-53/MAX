#include<CK_MAX.h>

void CK_MAX::ScrollMeRand(String message, Random_Scroll_Type R_T, Animation_Mode A_M, uint16_t duration, uint16_t wait){
	TRANSFER_THIS(message);
	
	byte BUFFER_SR[LENGTH_OF_MESSAGE];
	for(uint8_t index=0;index<LENGTH_OF_MESSAGE;index++){
		BUFFER_SR[index] =(byte)0;
	}
	
	/// RANDOMIZED
	randomSeed(analogRead(A5));
	int signeture[LENGTH_OF_MESSAGE];
	for(uint8_t index =0 ;index<LENGTH_OF_MESSAGE; index++){
		signeture[index]=-1;
	}
	uint8_t MY_CURSOR = 0;
	uint8_t Generated_number;
	while(MY_CURSOR < LENGTH_OF_MESSAGE){
		Generated_number = random(0, LENGTH_OF_MESSAGE);
		bool flag = false;
		for(uint8_t index=0;index<MY_CURSOR+1; index++){
			if(Generated_number == signeture[index]){
				flag = true;
			}
		}
		if(!flag){
			signeture[MY_CURSOR] = Generated_number;
			MY_CURSOR++;
		}
	}
uint8_t digit_index;
	if(A_M==ENTRY){
		for(uint8_t _index = 0; _index<LENGTH_OF_MESSAGE;_index++){
			for(uint8_t step = 0; step < 3;step ++){
				digit_index = signeture[_index];
				BUFFER_SR[digit_index] = 0b00000000;
				if(R_T==S_U_R){
					switch(step){
						case 0:
						bitWrite(BUFFER_SR[digit_index], 3, bitRead(MY_MESSAGE_BUFFER[digit_index], 6));
						break;
						
						case 1:
						bitWrite(BUFFER_SR[digit_index], 0, bitRead(MY_MESSAGE_BUFFER[digit_index], 6));
						bitWrite(BUFFER_SR[digit_index], 2, bitRead(MY_MESSAGE_BUFFER[digit_index], 1));
						bitWrite(BUFFER_SR[digit_index], 4, bitRead(MY_MESSAGE_BUFFER[digit_index], 5));
						bitWrite(BUFFER_SR[digit_index], 3, bitRead(MY_MESSAGE_BUFFER[digit_index], 0));
						break;
						
						case 2:
						BUFFER_SR[digit_index] = MY_MESSAGE_BUFFER[digit_index];
						break;
					}
				}else{
					switch(step){
						case 0:
						bitWrite(BUFFER_SR[digit_index], 6, bitRead(MY_MESSAGE_BUFFER[digit_index], 3));
						break;
						
						case 1:
						bitWrite(BUFFER_SR[digit_index], 0, bitRead(MY_MESSAGE_BUFFER[digit_index], 3));
						bitWrite(BUFFER_SR[digit_index], 6, bitRead(MY_MESSAGE_BUFFER[digit_index], 0));
						bitWrite(BUFFER_SR[digit_index], 1, bitRead(MY_MESSAGE_BUFFER[digit_index], 2));
						bitWrite(BUFFER_SR[digit_index], 5, bitRead(MY_MESSAGE_BUFFER[digit_index], 4));
						break;
						
						case 2:
						BUFFER_SR[digit_index] = MY_MESSAGE_BUFFER[digit_index];
						break;
					}
					
				}
				int LoopNumber = 0;
				byte RegNumber = 0;
				// DISPLAY SECTION.....
				int Cursor_pos = 0;
				for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(BUFFER_SR[Cursor_pos], LoopNumber, RegNumber);
				Cursor_pos++;
				}
				delay(duration);
			}
		}
		delay(wait);
		if(Internal_Refresh){
			RefreshMe();
		}
	}else{
		for(uint8_t index=0;index<LENGTH_OF_MESSAGE;index++){
		BUFFER_SR[index] =MY_MESSAGE_BUFFER[index];
	}
		       int LoopNumber = 0;
				byte RegNumber = 0;
				// DISPLAY SECTION.....
				int Cursor_pos = 0;
				for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(BUFFER_SR[Cursor_pos], LoopNumber, RegNumber);
				Cursor_pos++;
				}
		for(uint8_t _index = 0; _index<LENGTH_OF_MESSAGE;_index++){
			for(uint8_t step = 0; step < 4;step ++){
				digit_index = signeture[_index];
				BUFFER_SR[digit_index] = 0b00000000;
				if(R_T==S_U_R){
					switch(step){
						case 0:
						BUFFER_SR[digit_index] = MY_MESSAGE_BUFFER[digit_index];
						break;
						
						case 1:
						bitWrite(BUFFER_SR[digit_index], 0, bitRead(MY_MESSAGE_BUFFER[digit_index], 3));
						bitWrite(BUFFER_SR[digit_index], 6, bitRead(MY_MESSAGE_BUFFER[digit_index], 0));
						bitWrite(BUFFER_SR[digit_index], 1, bitRead(MY_MESSAGE_BUFFER[digit_index], 2));
						bitWrite(BUFFER_SR[digit_index], 5, bitRead(MY_MESSAGE_BUFFER[digit_index], 4));
						break;
						
						case 2:
						bitWrite(BUFFER_SR[digit_index], 6, bitRead(MY_MESSAGE_BUFFER[digit_index], 3));
						break;
						
						case 3:
						BUFFER_SR[digit_index] = 0b00000000;
						break;
					}
				}else{
					switch(step){
						case 0:
						BUFFER_SR[digit_index] = MY_MESSAGE_BUFFER[digit_index];
						break;
						
						case 1:
						bitWrite(BUFFER_SR[digit_index], 0, bitRead(MY_MESSAGE_BUFFER[digit_index], 6));
						bitWrite(BUFFER_SR[digit_index], 2, bitRead(MY_MESSAGE_BUFFER[digit_index], 1));
						bitWrite(BUFFER_SR[digit_index], 4, bitRead(MY_MESSAGE_BUFFER[digit_index], 5));
						bitWrite(BUFFER_SR[digit_index], 3, bitRead(MY_MESSAGE_BUFFER[digit_index], 0));
						break;
						
						case 2:
						bitWrite(BUFFER_SR[digit_index], 3, bitRead(MY_MESSAGE_BUFFER[digit_index], 6));
						break;
						
						case 3:
						BUFFER_SR[digit_index] = 0b00000000;
						break;
					}
					
				}
				int LoopNumber = 0;
				byte RegNumber = 0;
				// DISPLAY SECTION.....
				int Cursor_pos = 0;
				for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(BUFFER_SR[Cursor_pos], LoopNumber, RegNumber);
				Cursor_pos++;
				}
				delay(duration);
			}
		}
	}
}