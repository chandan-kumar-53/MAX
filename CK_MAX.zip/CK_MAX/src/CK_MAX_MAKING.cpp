#include<CK_MAX.h>

void CK_MAX::BuildMe(String message,Build_Type B_T,Animation_Mode A_M, uint16_t duration, uint16_t wait){
	TRANSFER_THIS(message);
	
	byte MY_BUFFER_ML[LENGTH_OF_MESSAGE];

///************************ANIMATION ENTRY****************************///
if(A_M == ENTRY){
	for(uint8_t index = 0; index < LENGTH_OF_MESSAGE ; index++){
		if(B_T == BREAKING){
			MY_BUFFER_ML[index] = 0b11111111;
		}else{
			MY_BUFFER_ML[index] = 0b00000000;
		}
		
	}
    int LoopNumber = 0;
		  byte RegNumber = 0;
		  // DISPLAY SECTION.....
		  int Cursor_pos = 0;
		  for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
		   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
		   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
		   ForceExecute(MY_BUFFER_ML[Cursor_pos], LoopNumber, RegNumber);
		   Cursor_pos++;
		  }
		  delay(duration);
		  
		  
	for(uint16_t index = 0; index<LENGTH_OF_MESSAGE; index++){
		for(uint8_t bitIndex = 0; bitIndex < 8; bitIndex++){
			if(B_T == BREAKING){
				if(bitRead(MY_MESSAGE_BUFFER[index], bitIndex)==0){
					bitWrite(MY_BUFFER_ML[index], bitIndex, 0);
					delay(duration);
				}
			}else{
				if(bitRead(MY_MESSAGE_BUFFER[index], bitIndex)==1){
					bitWrite(MY_BUFFER_ML[index], bitIndex, 1);
					delay(duration);
				}
			}
			int LoopNumber = 0;
		    byte RegNumber = 0;
		    // DISPLAY SECTION.....
		    int Cursor_pos = 0;
			  for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
			   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
			   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
			   ForceExecute(MY_BUFFER_ML[Cursor_pos], LoopNumber, RegNumber);
			   Cursor_pos++;
			  }
		}
	}
	delay(wait);
	if(Internal_Refresh){
		RefreshMe();
	}
}
	      
	
	

///**********************ANIMATION EXIT**************************************
if(A_M==EXIT){
	/// PRINT THE MESSAGE FIRST,
	       int LoopNumber = 0;
		    byte RegNumber = 0;
		    // DISPLAY SECTION.....
		    int Cursor_pos = 0;
			  for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
			   LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
			   RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
			   ForceExecute(MY_MESSAGE_BUFFER[Cursor_pos], LoopNumber, RegNumber);
			   Cursor_pos++;
			  }

		for(int index = 0;index<LENGTH_OF_MESSAGE;index++){
			MY_BUFFER_ML[index] = MY_MESSAGE_BUFFER[index];
		}

	/// IF MAKE...
	if(B_T==MAKING){
		for(uint8_t digit = 0; digit <LENGTH_OF_MESSAGE ; digit++){
			for(uint8_t bitIndex = 0; bitIndex<8; bitIndex++){
				if(bitRead(MY_BUFFER_ML[digit], bitIndex)==0){
					bitWrite(MY_BUFFER_ML[digit], bitIndex, 1);
					delay(duration);
				}
				int LoopNumber = 0;
		        byte RegNumber = 0;
		        // DISPLAY SECTION.....
				int Cursor_pos = 0;
					for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
						LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
						RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
						ForceExecute(MY_BUFFER_ML[Cursor_pos], LoopNumber, RegNumber);
						Cursor_pos++;
					}
			   }
		   }
		   if(Internal_Refresh){
		    RefreshMe();
	      }
	    }else{
			for(uint8_t digit = 0; digit <LENGTH_OF_MESSAGE ; digit++){
				for(uint8_t bitIndex = 0; bitIndex<8; bitIndex++){
					if(bitRead(MY_BUFFER_ML[digit], bitIndex)==1){
						bitWrite(MY_BUFFER_ML[digit], bitIndex, 0);
						delay(duration);
					}
					int LoopNumber = 0;
					byte RegNumber = 0;
					// DISPLAY SECTION.....
					int Cursor_pos = 0;
						for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
							LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
							RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
							ForceExecute(MY_BUFFER_ML[Cursor_pos], LoopNumber, RegNumber);
							Cursor_pos++;
						}
				}
			}
		}
    }	
}