/**
@THIS FILE, 
            EXPERIMENTED ON
			       -  OWN_SLICE (double effect)
				   -  ALL_SLICE (double effect)
				   -  SCROLL_UP (double effect)
				   -  SCROLL_DOWN (double effect)
				   
			CHANDAN KUMAR MONDAL (C) - 19 MAY, 2020
*/

#include <CK_MAX.h>

/**
   \name  SliceMe
   \brief Slicing Effect Acts on a single character. It's has two category
           - slice all
		       * Effect In
			   * Effect Out
		   - slice own
		       * Effect In
			   * Effect Out
			   
	\def slice all (In effect)
	    -> Display Initially clear from Digit position(digit_pos) to digit_pos + length of message.
		-> First Character of message( \param ) come from (digit_pos + length of message) and fixed to digit pos.
		-> Second Character of message( \param ) come from (digit_pos + length of message) and fixed to digit_pos+1
		-> Every step's digit will be cleared ( it is the only difference from the slice own).
		
	\def slice all (Out effect)
	    -> First print the message( \param ) in the display.
		-> Every time take last character and slide until the position will be maximum (Number_of_Device*DIGIT_NUMBER)
		-> And Every step must be cleared.
		
	\def slice own (In effect)
	    -> Only difference from slice all is, it doestn't clear any digit.
		-> Character will be over written.
		
	\def slice own (Out effect)
	    -> Print the message ( \param )
	    -> Simply Remove from the last character of the message ( \param ).
		   
*/
void CK_MAX::SliceMe(String message, Slicing_Type S_T,Animation_Mode A_M, uint16_t duration, uint16_t wait){
	TRANSFER_THIS(message);
	
	///..........MAIN SECTION................///
	if(A_M==ENTRY){
		uint8_t cursor = 0;
		uint8_t Loop = 0;
		byte Reg = 0;
		byte Current_Digit = 0;
			for(uint8_t Stay_Here = digit_pos ; Stay_Here>=digit_pos - LENGTH_OF_MESSAGE ;Stay_Here--){
				for(uint16_t buf = digit_pos - LENGTH_OF_MESSAGE +1 ; buf<=digit_pos-cursor; buf++){
					Loop = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-buf);
					Reg  = buf - ((Loop-1)*DIGIT_NUMBER);
					ForceExecute(MY_MESSAGE_BUFFER[cursor], Loop, Reg);
					if(S_T==ALL_SLICE){
						Loop = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-(buf+1));
						Reg  = (buf-1) - ((Loop-1)*DIGIT_NUMBER);
						ForceExecute(0b00000000, Loop, Reg);
					}
					delay(duration);
				}
				cursor++;
			}
			delay(wait);
		if(Internal_Refresh){
			RefreshMe();
		}
	}else{
		if(S_T==OWN_SLICE){
			/// PRINT THE MESSAGE FIRST.....
			int LoopNumber = 0;
			byte RegNumber = 0;
			// DISPLAY SECTION.....
			int Cursor_pos = 0;
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(MY_MESSAGE_BUFFER[Cursor_pos], LoopNumber, RegNumber);
				Cursor_pos++;
			}

			/// THEN LIT OFF ONE ARFER ONE DIGIT
			Cursor_pos=0;
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(0b00000000, LoopNumber, RegNumber);
				Cursor_pos++;
				delay(duration);
			}
		}else{
			// DIPLAY BUFFER
			byte DISPLAY_BUFFER_SL[LENGTH_OF_MESSAGE];
			// STORE THE VALUE
			for(uint8_t index = 0; index<LENGTH_OF_MESSAGE; index++){
				DISPLAY_BUFFER_SL[index]=MY_MESSAGE_BUFFER[index];
			}
			// PRINT THE LINE FIRST
			int LoopNumber = 0;
			byte RegNumber = 0;
			int Cursor_pos = 0;
			for(int i = digit_pos; i>digit_pos-LENGTH_OF_MESSAGE; i--){
				LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-i);
				RegNumber  = i - ((LoopNumber-1)*DIGIT_NUMBER);
				ForceExecute(DISPLAY_BUFFER_SL[Cursor_pos], LoopNumber, RegNumber);
				Cursor_pos++;
			}

            uint8_t digit_index = LENGTH_OF_MESSAGE-1;
			for(int location = digit_pos-LENGTH_OF_MESSAGE+1 ; location<=digit_pos; location++){
			    if(DISPLAY_BUFFER_SL[digit_index] != 0b00000000){ //IGNROE THE SPACE
					for(int slide = location; slide>=0;slide--){
						LoopNumber = givethecursor(((DIGIT_NUMBER*Number_of_Device)+1)-slide);
						RegNumber  = slide - ((LoopNumber-1)*DIGIT_NUMBER);
						ForceExecute(DISPLAY_BUFFER_SL[digit_index], LoopNumber, RegNumber);
						delay(duration);
						ForceExecute(0b00000000, LoopNumber, RegNumber);
				    }
				}				
				digit_index--;
			}
		}
	}
			
}

